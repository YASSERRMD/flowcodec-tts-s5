# FlowCodec-TTS-S (L4→CPU) — v5
HF dataset + precomputed codec latents for efficient training on a single NVIDIA L4.
New: checkpointing + EMA, latent index, length-bucket sampler.

See README inside for commands.
